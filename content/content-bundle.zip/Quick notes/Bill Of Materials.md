##### Definition:

String that contains all module SKUs and their positions in encoded form.

##### Example:
_SL27B-334_100-pine-SB99CL-AC21S-CL21-AC23F-SH04-BL06F1.180-BL21G1.180-BL21E1.180-ET35D-RW20A-LA25A-AC01L4-scope4-TS17B-BL06C.145-BT20X-RF18X_

##### Explanation:
1. The '-' separates two BOM elements. 
2. A bom element provides information on a single module or on the entire configuration
	1. Consider BL21E1.180. BL21 is the SKU of a type of balustrade. E1 is the position of that balustrade in the customer's configuration. 180 is its height in cm.
	2. 334_100 indicates that all slides have the colour yellow (or some other colour, not sure)


