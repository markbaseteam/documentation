# Pipeline Overview
## List of all stages
 - [[CreateSalesStage]]
 - [[RetrieveSalesStage]]
 - [[SubmitSalesStage]]
 - [[FullEDIStage]]
## Pipeline from a sales order point of view
```mermaid
graph TD
	
	CreateSalesStage --> RetrieveSalesStage --> SubmitSalesStage --> FullEDIStage
	class CreateSalesStage,RetrieveSalesStage,SubmitSalesStage,FullEDIStage internal-link;
```
## Pipeline from an execution point of view
```mermaid
graph TD
	
	CreateSalesStage & RetrieveSalesStage & SubmitSalesStage --> S
	S{ } -- Synchronization Point --> FullEDIStage
	class CreateSalesStage,RetrieveSalesStage,SubmitSalesStage,FullEDIStage internal-link;
```
