# RetrieveSalesStage
[[SalesOrderStage]] to get all the information about the sale in Magento and load it into the EDI. Comes after [[CreateSalesStage]]