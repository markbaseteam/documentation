# CreateSalesStage
[[SalesOrderStage]] to create a database entry in the EDI for every sale in Magento currently in state Processing. Very first stage