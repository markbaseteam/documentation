# SubmitSalesStage
[[SalesOrderStage]] to submit all the sales in the EDI to Odoo. Comes after [[RetrieveSalesStage]]
