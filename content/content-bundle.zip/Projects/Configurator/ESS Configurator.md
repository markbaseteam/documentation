# ESS configurator

## Introduction
The configurator was built by [EagleScience Software](https://www.eaglescience.nl). They already created extensive [Confluence documentation](https://confluence.eaglescience.nl/display/JG/JungleGym) on the process.

[[_TOC_]]

## History
### Expivi
The ESS configurator is not the first configurator that [[Jungle Gym]] uses. Its predesessor is the [[Expivi 3D configurator]], which is currently (May 2022) still in use. 

## Configurator
### Frontend
See [the latest version](https://develjgconaccependpoint.azureedge.net/).


### Portal
See [the latest version](https://develjgcmsaccependpoint.azureedge.net/)


## Process
[[ESS Configurator process]]


## Tags
#ESS, #configurator