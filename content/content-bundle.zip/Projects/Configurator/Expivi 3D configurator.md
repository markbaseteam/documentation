Customizable configurator.

The customer of expivi can design their own configurator, using [[Expivi]]'s software. We created multiple [Expivi configurator](https://www.junglegym.nl/my-jungle-gym-medium)s.

The end user of this tailored configurator sees a 3D canvas in which different parts of a 3D model can be hidden or visible depending on the choices the end user makes in a side panel. 

The questions and parts of the 3D model derive from a .fbx file uploaded by the customer of expivi (generally a company). This .fbx has a predefined hierarchy and naming scheme, allowing it to be parsed. 