# Configurator rules

```toc 
style: number min_depth: 0 max_depth: 0 
```

## Quick intro
Rules are a vital part of the configurator. Blueprints, attachment points and their properties ensure that only matching modules can be coupled. But for more complex behaviour in the configurator we need the rule executor. Whenever you need certain modules to be automatically placed, changed or removed, you need to write a rule. And there are many more possibilities.

In general one can say that a rule consists of two parts: `IF some trigger` & `THEN do something`

## Types of rules
There are three types of rules you can write: **Event**, **Blueprint** and **Environment**. 

### Event rules
Event rules are scripts defined at the scope of a blueprint and are only executed when triggered by certain common events: **onAttach**, **onDelete**, **onCreated**, **onChange**. 

> [!EXAMPLE]-  Example: onAttach
>> `IF` 
> you attach a swing` 
> 
>> `THEN`
> attach a swing seat to each x-attachment point on that swing

### Blueprint rules
Blueprint rules are also defined at the scope of a blueprint. The difference with the event rules is that you can write your own triggering condition. This is called an invariant: something that should always be `true`. When this condition is not met - the invariant is `false` - then you can write a correction rule to change the configuration in such a way that the condition is met anyway.


> [!EXAMPLE]- Example: balustrade
>> `IF NOT`
> All x-attachment point in this tower blueprint have some module attached to it
> 
>> `THEN`
> attach a balustrade to all the empty attachment points


### Environment rules
Environment rules function similar to blueprint rules but are defined at the scope of a retailer. You write condition that must not be met per blueprint, but for your entire configuration.

> [!EXAMPLE]- Example: means of access
>> `IF NOT`
> a means of access is present in the configuration
> 
>> `THEN`
> try to fit a means of access to an attachment point that is consideredFree (e.g. a balustrade). If there is no module consideredFree, then attach a means of access to the first attachment point you can find. 

### Which rule type to choose? (advanced reading)
Sometimes it can be hard to think of which of the above types to choose when you want to establish a certain kind of behaviour. 

> [!EXAMPLE]+ Example: bottom up rule
> For instance: when you want to make sure your extension tower has high poles when there is a rope ladder attached to it, what do you do? 
> 1. Do you create a onAttach rule for the rope ladder that picks the compatible ETxx and a onDelete rule that restores the old extension tower when one removes the rope ladder? 
> 2. Do you write a blueprint rule that checks for each extension towers if any modules are attached that require high poles. If so then it changes itself to a ET with high poles. Then a opposite rule for all the extension towers with high poles so that it changes to a low pole extension tower when no modules require high poles.

^8267a9

Event rules are more efficient because the invariant rules don't have to be executed at any configuration change. Downside is that if a rope ladder is deleted it changes the ET to a lower pole version, even though another module might still require high poles. Blueprint rules in this case are more rigorous because there check if there is **any** module that requires higher poles, but it comes at the cost of efficiency. Whenever you choose the efficient one over the safe one, be sure to document the implications well and adopt them as part of the conventions when adding or amending blueprints. 


## Rule purposes (optional)
There are several reasons to write rules. When rules conflict it might be nice to have a way to prioritise them. Although, arguably, different categorisations could be made, hopefully this provides the rule writer with some means. 


### Basic behaviour (must have)
Without the [[bounding_box_overlap]] rule all modules could simply overlap. 

### Safety (must have)
Safety rules are necessary. They ensure that no unsafe configurations can be designed. Without these rules the configurator should be put offline.

### Compatibility (should have)
Compatibility between modules is mostly ensured by the attachment points and their properties. Yet, sometimes rules are also required (such as the bottom up rules in [[#^8267a9|this example]]). 

### Logistics (should have)
Best explained by an example: the AC01 should be part on every order for all retailers because it contains the generic part of the manual. To ensure it is present, one should write a rule

### Other (nice to have)
Default placements for marketing purposes or other UX reasons could be found here

## Rule table

| Name                          | Type        | Function        | Id                                   | Ready? |
| ----------------------------- | ----------- | --------------- | ------------------------------------ | ------ |
| [[Bounding_box_overlap]]      | Environment | Basic behaviour | f43a2c8b-3ff7-4bcb-a1d4-ec32d4b8ffff | Yes    |
| [[Means_of_access]]           | Environment | Safety          | b3e9270b-1084-4018-9f07-92f684906a0e | Yes    |
| [[swing-seat_slide_distance]] | Environment | Safety          | 42521bc0-5006-4f60-b408-64a3eb085b1f | Partly |
| [[At_least_one_BT]]           | Environment | Basic behaviour | 2f1d8c12-d135-499f-9708-242099851459 | Partly |
| [[AL_balustrades]]            | Blueprint   | Safety          | 26f085d3-4864-4379-93a8-13cb64d0ca42 | Yes    |
| [[CL_balustrades]]            | Blueprint   | Safety          | 9dd76087-6cf3-4a64-b9b1-a6bb9fb7c195 | No     |
| [[DL_balustrades]]            | Blueprint   | Safety          |                                      | No     |
| [[Add_bridge_to_frame]]       | Event       | Compatibility   | d62b1c77-8d19-470e-969d-dbf90e0d2ca2 | No     |
| [[Add_BT03_to_CB]]            | Event       | Compatibility   | df1285a5-90a5-4460-8314-4478f1dcf117 | No     |
| [[AC01_always_present]]       | Environment | Logistics       | 88bab0b9-2c45-4165-a727-56c0f8d6b6d6 | Yes    |
| [[Requires_high_poles_AL]]    | Blueprint   | Basic behaviour |                                      | No     |
| [[Requires_high_poles_CL]]    | Blueprint   | Basic behaviour |                                      | No     |
| [[Requires_high_poles_DL]]    | Blueprint   | Basic behaviour |                                      | No     |