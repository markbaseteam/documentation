# How to: export [[blueprint|blueprints]] via Blender

To add new modules to the portal one must upload both a JSON and a 3D model in .glb format. The 3D model requires a hierarchy that can be parsed in the portal. This structure can be setup in Blender in 7 steps:

1. Create a new `Collection` with the same name as the SKU/Blueprint you're setting up (ignore whether you see symbols on the right for now)<br> ![[Blender_instructions_0.png]]
2. Create the three elements in the `Collection` 
	1. New `Collection`: landing_zones2
	2. New `Collection`: AP
	3. Your 3D object <br> ![[Blender_instructions_1.png]]
3. Add a new `Collection` called 'landing_zone' to 'landing_zones' and add an empty `cube` <br> ![[Blender_instructions_2.png]]
	1. The dimensions of the cube should match the landing zone
4. Add two new `Collection`s to AP called 'X' and 'Y'<br>![[Blender_instructions_3.png]]
	1. Add all the x and y attachment points as empty `Simple Arrow` to the corresponding `Collection`.
		1. x APs are present for among other things
			1. Regular modules <br>![[Blender_instructions_3a.png|400]]
				1. Position
					1. Middle of the outer line between the poles, below floor
						1. e.g. BT01: (x: 0.37, y: 0.37, z: 1.23) 
				2. Rotation
					1. Outward, perpendicular to the tower.
				3. Properties
					1. Add the active properties as custom properties to the x AP arrow object
					2. For "normal" modules
						1. AL/CL/DL
						2. T/U
						3. L/R
						4. etc...
							
			2. Swings<br>![[Blender_instructions_3b.png|400]]<br>![[Blender_instructions_3c.png|400]]
				1. Position
					1. Center of the side of the beam that in the tower
				2. Rotation
					1. Outward and perpendicular to the tower
				3. Properties
					1. Swing, 
					2. 1.90/2.10
			3. Roofs
				1. Position
					1. (x: tower center, y: tower center, z: tower height)
				2. Rotation
					1. Upward
				3. Properties
					1. AL/CL/DL
					2. 'roof'
			4. Accessories
				1. Wherever they are desired
			5. Swing seats
				1. Position
					1. Bottom of the swing beam
					2. Middle of the hooks it is attached to
				2. Rotation
					1. Downward
		2. y APs 
			1. Position such that the module fits perfectly if its the same as the x AP it can attach to
			2. Rotation should be the opposite direction
5. Add 3D model with mesh <br>![[Blender_instructions_4.png|250]]
	1.  There is a naming scheme for the meshes:
		1. \[SKU\]\_variantMesh\[enumeration\]

> [!WARNING]+ The screenshot above is not exactly what it should look like. 
> 
> 'CB01 - tilted' should also be named CB01_variantMesh0.
> 
> Otherwise the materialChange in a variant will not be able to find the mesh it should change.
> Contents



%%6. Set the 3D model mesh as parent to all the `empties` i.e. APs and landing_zones
	1. Select all empties while holding `CTRL`. Lastly select the mesh. <br>![[Blender_instructions_5.png|250]]
	2. Move your mouse to the viewport (3D environment on the left)
	3. Press `CTRL` + `p`
	4. Select `Object`<br> ![[Blender_instructions_6.png|400]]
7. Check if your result looks like this<br>![[Blender_instructions_7.png|250]]%%

Now you can export it as a .glb

> [!WARNING]+ Export correctly
> Do not forget to check the box for exporting the `Custom Properties` you added and to click `Geometry|materials -> No export`.
> ![[Blender_export_glb.png]]



## Tags
#eagle-science #configurator #instructions #blender #how-to