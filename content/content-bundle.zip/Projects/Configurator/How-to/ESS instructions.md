# Configurator
# Portal
1. [[Add retailer]]
2. [[Add blueprint]]
3. [[Change prices]]
4. [[Change descriptions]]
5. [[Change stock availability]]
6. [[Write rules]]
# Blender
1. [[Export 3D models]] suitable for the [[Notes/Notes/ESS configurator#Portal|portal]]





****
