
This page contains dynamic notes on the process of building the [[documentation/Projects/Configurator/ESS Configurator]]. Among other things, you can find the latest todos below.

[_TOC_]


## Planning


### Production environment inputs
#### 3D models
#### Parser
#### Automation pipeline
#### List of modules to be imported
Based on this [list of SKUs](https://docs.google.com/spreadsheets/d/1FcbI0h4c1E4MiEOOEyr8Gb6mfJlqD_PmYXvVc_A5-xQ/edit)

See comments per blueprint in google sheet
#### Foto's per blueprint aanleveren




## Unmet conditions for MVP
1. Configurator
	1.  Algemeen
		1. Tutorial
	2. Design
		1. Regels
			2. Landing zones
		2. Koppelpunten
			1. Op de voorgrond
			2. Zichtbaar als juiste richting etc.
			3. Groeperingen werkend
		3. Torenwijziging
			1. Hoogte
			2. Breedte
		4. Toggles
			1.  Houtsoort
				1. Inclusief kleurverandering
			2. Montage
			3. Maten
				1. Zichtbaar in 3D
		5. Catalogus
			1. Plaatjes
			2. Grijze velden
		6. Layout
			1. Overeenkomstig wireframes
		7. 
	3. Result
		1. Achtergrond
		2. Extra info
2. Portal
3. Manual
	1. Topview
		1. Maten
		2. Zijde-indicatoren
	2. Zij-aanzichten
	3. Zijde-indicatoren in config file
	4. API call
4. External use
	1. Access shopping cart
	2. Plugin
5. 

### Prioriteiten configurator
1. Eindgebruiker
	1. Veilig speeltoestel
	2. Mobile first
	3. Eenvoudig:
		1. Volgen conventies
		2. Intuitieve bediening en navigatie
		3. Makkelijke keuzes
	4. Aantrekkelijk
		1. Renders
		2. Achtergrond
		3. Buttons
	5. Uitgebreid
		1. Ruim aanbod van modules
		2. Zelfde opties als wysiwyg
	6. 
2. Jungle Gym-medewerker




## Requests
1. Configurator
	1. Add button to catalog that executes a function
		1. Can we use an empty blueprint?
	2. Better lighting
	3. 
## Open questions
1. What to do with the challenger line? --> ![[ESS Configurator process#^96b5d2|One AP]]
	1. One AP for 1.5 module per side
	2. Four/five APs per side
2. How to automatically replace a module?
3. How to build to catalog in the portal?
4. How do AP matches work? 
	1. Still a list of allowed combinations of properties?
		1. How bad would that be?

## JungleGym todos
1. Discuss and notify ESS
	1. How to depict wood type question?
		1. Separate screen?
		2. Simple toggle
	2. SLA etc.
		1. Subscription for maintenance?
		2. Up-time
		3. Response time
	4. Which ISO norms should be met?
		1. 27001?
2. Send information to ESS
	1. Manual generator 2.0 project
	2. Magento plugin
	3. Thomas's Holidays
3. 

## Notes 
1. Configurator
	1. Slides can still overlap
	2. APs do not work properly
		1. Hidden in objects
		2. Some must disappear
	3. A fort is not possible
	4. Higher and wider towers are no option
	5. I cannot open the configurator in my newly designed scope.
	6. Roofs cannot be rotated yet
	7. Grey modules do not present an explanation
	8. Edit icons do not appear on a spot that makes sense
	9. If you remove a swing it does not place a balustrade
	10. Only edit icons for towers; For the other ones we could work with deselection in the catalog.
2. Result view
	1. Also show chosen options (wood type and assembly service)
3. Portal
	1. You can upload any file type as 3D model
	2. You cannot see category IDs
	3. There is no live testing environment
	4. There is no input for text
		1. Nor do I know what it will look like
	5. you cannot change or see the catalog
4. Clicking a scope option in inventory input leads to another block appearing selected.
5. Zoom at mouse point
6. Use external textures and materials



# Decisions
1. Challenge line has one AP per side.  ^96b5d2
	1. A blueprint has to be made that contains both the slide and the balustrade
2. ~~Discovery beam is a struct~~


# Issues
1. Als je een blueprint/variant wijzigt, maa rde SKU blijft hetzelfde dan doet hij alsof hij niet op voorraad is. -> Zie gesprek rocketchat phofma 07/10/2022
2. 