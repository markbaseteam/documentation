## Required inputs voor manual generator [^1]
1. Five base64 images
	1. Topview
		1. Measures
		2. Side indicators
	2. Sideview
	3. Frontview
	4. Angle view
2. Configuration name
3. Skus
	1. Plus side indicator
4. (wood_type)
5. Configuration code


[1]: Sent as such to Wender van Mansvelt at 30-09-2022