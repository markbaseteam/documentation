Custom poster generated alongside the [[manual pdf]] in the [[1. Manual generator (Expivi)|Expivi manual generator]]. 

See [example](https://junglegym.com/media/wysiwyg/dyo_manuals/wallpapers/NLNLSO_000007375-wallpaper.pdf).