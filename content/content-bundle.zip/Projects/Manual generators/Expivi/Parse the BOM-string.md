DYO [[Expivi 3D configurator]] orders have a [[Bill Of Materials]] (BOM) outputted by Expivi in their order. This string must be parsed to be used in the [[1. Manual generator (Expivi)|manual generator]].

[[_TOC_]]

## BOM-string

![[Bill Of Materials]]


## Parsing
The [[1. Manual generator (Expivi)|manual generator]] only needs the modules and their positions. Let a BOM string be a number of `element`s separated by '-'.

 - Generic case:
	 - `element` is a module and contains no '.'
		 - `module = sku[:4]`
		 - `side = sku[4:]`
 - 

There are a lot of edge cases when interpreting the elements of the BOM string.


