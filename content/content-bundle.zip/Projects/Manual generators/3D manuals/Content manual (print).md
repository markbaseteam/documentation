# Universeel 
- pdf
- In de doos van AC01 
- Inhoud 
	- Safe playzone 
		- universeel gedefinieerd 
	- Fundamentplan 
	- Universele hardware 
		- Hardware identification page 
# Overview configuratie (assembly) 
- Digitaal 
- Papier 
	- Images 
		- Poster image 
		- Topview 
			- Netto ruimtebeslag (l x b) 
		- Front view (b x h) 
		- Side view (l x h) 
		- Plattegrond assembly 
	- Tabellen (totaaloverview content parts) 
		- Hout 
		- Construction kits 
		- Assembly planning table 
# How to build SKU (subassemblies)
- Digitaal 
	- image 
- Papier 
	- pdf