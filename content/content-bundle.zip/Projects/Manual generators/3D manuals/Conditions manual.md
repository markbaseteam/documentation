
# Introductie
Wanneer een klant bij ons een Design Your Own speeltoestel bestelt ontvangt deze een mail met daarin een link naar een manual. Op dit moment is dat een [pdf](https://junglegym.com/media/wysiwyg/dyo_manuals/NLNLSO_000007375.pdf), maar we willen graag een interactieve manual met 3D omgeving. 
Hier is het overzicht van waar wat ons betreft een 3D manual aan moet voldoen. We hebben de randvoorwaarden beschreven en de vijf onderdelen van een 3D handleiding. Die onderdelen moeten op een manier terugkomen op een webpagina, maar de manier waarop kan nog ingevuld worden (wisselen tussen onderdelen, scrollen van boven naar beneden, etc.). 
Er moet ook een printversie zijn waar al deze onderdelen onder elkaar worden gezet in een pdf (inclusief alle modules die in de webversie stuk voor stuk worden toegevoegd.)



# Randvoorwaarden

Een handleiding is

1. Veilig
	1. Bevat alle veiligheidsvoorschriften en correcte uitvoering leidt altijd tot een veilig toestel
	2. Informatie die de klant tot zich moet nemen staat wordt standaard weergegeven
		1. e.g. toggle van valruimte staat standaard aan.
		2. e.g. veiligheidspagina is de landing page
2. Compleet
	1. Bevat instructies voor alle SKU's die in de order voorkomen
3. Herleidbaar
	5. Alle onderdelen zijn terug te voeren naar de order
4. Printbaar
	1. Er is een overzichtelijke 'lineaire' versie van de handleiding


# Onderdelen van een manual

## 1. Algemeen
- Veiligheid
	- Glijbaanrichting niet op zuiden
- Ankerplan

## 2. Tabellen [¹]
- Houtlijsten
- Hardware

## 3. 3D geheel toestel

- Maten (toggle)
	- Rastering (?)
	- Per grote module (?)
- Knoppen voor aanzichten
	- Topview
		- Valruimte aan
			- Twee meter rondom buitenkant speeltoestel vrijhouden
		- Maatvoering
			- Inclusief en exclusief valruimte
		- Noordpijl (glijbaan niet op het Zuiden) (?)
	- Zij-aanzichten
		- Hoogtemaat aan



## 4. 3D assemblage
- Een voor een modules in toestel 'schuiven'
- Volgorde
	- Voorgedefinieerde lijst met SKU's
		- e.g. eerst alle torens
	- De configuratie aflopen
		- eerst een toren inclusief modules, dan door naar de volgende
		
## 5. Modulehandleidingen
- Instructies per SKU
- In deze versie in pdf
	- Later misschien een soort [Solidworks composer](https://www.solidworks.com/product/solidworks-composer) 


# Print
In de lineaire versie van de manual moeten alle stappen aanwezig zijn --> veel snap shots
- Algemeen
- Tabellen
- 3D geheel toestel
	- Screenshots van verschillende modi
		- Bovenaanzicht
			- Maten aan
			- Valzone aan (contour +2m)
		- Zij-aanzichten
			- Maten aan
- 3d assemblage
	- Screenshot van elke nieuwe module die aan het geheel wordt 'geschoven'

# Inspiratie
- Lego
	- [Filmpje]()
	- [App](https://apps.apple.com/us/app/lego-building-instructions/id1486159728)
- [Solidworks composer](https://www.solidworks.com/product/solidworks-composer)
- [Juridische eisen](https://instrktiv.com/en/create-online-manual/?vgo_ee=eExsYc5kKHAglmsrsErfzBwUnRnlmwiuCIJkd9A7F3A%3D)
- Voorbeeld [oude manual](https://drive.google.com/file/d/1PZHo0hXFdh9QXo3tf5tKK6Qa_rqJJDlm/view)
- Voorbeeld [huidige custom pdf](https://junglegym.com/media/wysiwyg/dyo_manuals/NLNLSO_000007375.pdf)

[¹]: De tabellen zijn aggregaten van benodigdheden per SKU. Op dit moment is de inhoud van een cel uit een tabel niet direct herleidbaar naar de SKU's waarvan het een optelling is. Misschien moeten we die nog uitbreiden daarom. 