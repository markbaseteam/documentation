The [[DYO 1]] JungleGym manual for Expivi products is in .pdf format and created by the [[1. Manual generator (Expivi)|Expivi manual generator]]

See [example](https://junglegym.com/media/wysiwyg/dyo_manuals/NLNLSO_000007375.pdf)