# Dockerizing the manual generator

## Concepts
### Dockerfile
1. Installing 

### Docker compose
#### Service: manual generator
#### Mounting a Google drive volume [[#^fad114]]


## Resources:
1. https://docs.docker.com/get-started/
2. https://andrewdoering.org/blog/2021/12/31/using-docker-compose-for-media-automation/#requirements ^fad114
3. 