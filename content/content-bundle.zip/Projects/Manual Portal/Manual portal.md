##### Definition:
[Public website](https://www.start.junglegym.nl) where customers can find [[DYO 1]] and [[WYSIWYG 1]] manuals.

##### Quick facts:
- Desired design can be found in [Figma](https://www.figma.com/file/M2TDaYvz3wcIWHafl8wU68/Jungle-Gym?node-id=1316%3A28677)
- Codebase is at [GitLab](https://gitlab.com/j2655/manual-portal)
	- Vue framework



