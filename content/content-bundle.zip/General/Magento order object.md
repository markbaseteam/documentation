[[Python]] object that contains information on [[Magento]] orders and provides functions to interact with them. 

```{python}


```