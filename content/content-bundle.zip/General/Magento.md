_Magento_ is an open-source e-commerce platform written in PHP.

Visit our own [Magento Dashboard](https://www.junglegym.com/magemanager/admin/dashboard).
