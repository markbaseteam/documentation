FTP server at [junglegym.hypernode.io](http://www.junglegym.hypernode.io).

All [[manual pdf|manual pdfs]][^example_url] are stored and accessible for customers on this server[^manual].

[^example_url]: See [example url](https://junglegym.com/media/wysiwyg/dyo_manuals/NLNLSO_000007375.pdf). 

[^manual]: Customers can access the server through direct link of via the [[Manual portal]]